//
// Copyright (c) 2001 Andrew Fernandes <andrew@fernandes.org>. All rights reserved.
//
// This work may be used and distributed under the terms of the GNU Public License,
// as written in the included file "gpl.txt" or online at <http://www.gnu.org/>.
//
#include <windows.h>
#include <stdio.h>
#define WINSCARDDATA __declspec(dllexport)
#include <winscard.h>
extern "C" {

/* ******************************************************************************* */

static HANDLE  hOut=0;
static HMODULE hOriginal=0;

/* ******************************************************************************* */

/* The following values variables MUST be defined here, but MUST NOT be referenced
   in this or any other program module. The DEF file is set to forward their linkage
   to the "original.dll". If we need the data that these variables should be pointing
   to, we must GetProcAddress on "original.dll" and use the data there.
*/
const SCARD_IO_REQUEST g_rgSCardT0Pci, g_rgSCardT1Pci, g_rgSCardRawPci;
/* Just make sure we don't accidentally use the wrong global variable... */
#define g_rgSCardT0Pci   DONT_USE_ME_g_rgSCardT0Pci
#undef  SCARD_PCI_T0
#define SCARD_PCI_T0     DONT_USE_ME_SCARD_PCI_T0
#define g_rgSCardT1Pci   DONT_USE_ME_g_rgSCardT1Pci
#undef  SCARD_PCI_T1
#define SCARD_PCI_T1     DONT_USE_ME_SCARD_PCI_T1
#define g_rgSCardTRawPci DONT_USE_ME_g_rgSCardTRawPci
#undef  SCARD_PCI_RAW
#define SCARD_PCI_RAW    DONT_USE_ME_SCARD_PCI_RAW

    
/* ******************************************************************************* */

void DumpMemory( LPCBYTE location, DWORD length ) {

    DWORD i, written;
    char *hexDigit = "0123456789ABCDEF";
    char *space = " ", *crlf = "\r\n";
    
    WriteFile( hOut, space, lstrlen(space), &written, NULL );
    for ( i=0; i<length; i++ ) {
        WriteFile( hOut, space, lstrlen(space), &written, NULL );
        WriteFile( hOut, (hexDigit+((location[i]>>4)&0x0F)), 1, &written, NULL );
        WriteFile( hOut, (hexDigit+((location[i]>>0)&0x0F)), 1, &written, NULL );
        if ( ( (i+1) % 26 == 0 ) && ( (i+1) < length ) ) {
            WriteFile( hOut, crlf, lstrlen(crlf), &written, NULL );
            WriteFile( hOut, space, lstrlen(space), &written, NULL );
        }
    }
    
    WriteFile( hOut, crlf, lstrlen(crlf), &written, NULL );
    
}

/* ******************************************************************************* */

static WINSCARDAPI LONG (WINAPI *Original_SCardTransmit)(
  IN SCARDHANDLE hCard,  
  IN LPCSCARD_IO_REQUEST pioSendPci,
  IN LPCBYTE pbSendBuffer,
  IN DWORD cbSendLength,
  IN OUT LPSCARD_IO_REQUEST pioRecvPci,
  OUT LPBYTE pbRecvBuffer,
  IN OUT LPDWORD pcbRecvLength
);

WINSCARDAPI LONG WINAPI SCardTransmit(
  IN SCARDHANDLE hCard,  
  IN LPCSCARD_IO_REQUEST pioSendPci,
  IN LPCBYTE pbSendBuffer,
  IN DWORD cbSendLength,
  IN OUT LPSCARD_IO_REQUEST pioRecvPci,
  OUT LPBYTE pbRecvBuffer,
  IN OUT LPDWORD pcbRecvLength
) {

    LONG result; 
    DWORD written;
    char *txMsg   = " transmitted:\r\n";
    char *rxMsg   = " received:\r\n";
    char *crlf    = "\r\n";
    const bufferLength = 1024;
    char buffer[bufferLength];

    sprintf(buffer,"SCardTransmit (handle 0x%0.8X):\r\n",hCard);
    WriteFile( hOut, buffer, lstrlen(buffer), &written, NULL );
 
    WriteFile( hOut, txMsg, lstrlen(txMsg), &written, NULL );
    DumpMemory( pbSendBuffer, cbSendLength );    

    result = (*Original_SCardTransmit)(hCard,pioSendPci,pbSendBuffer,cbSendLength,pioRecvPci,pbRecvBuffer,pcbRecvLength);
    
    WriteFile( hOut, rxMsg, lstrlen(rxMsg), &written, NULL );
    DumpMemory( pbRecvBuffer, *pcbRecvLength );
    
    WriteFile( hOut, crlf, lstrlen(crlf), &written, NULL );
    
    return result;

}

/* ******************************************************************************* */

BOOL WINAPI DllMain( HINSTANCE hDllInst, DWORD fdwReason, LPVOID lpvReserved ) {

    switch (fdwReason) {

        case DLL_PROCESS_ATTACH:
            hOut = CreateFile("winscard.txt",GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
            if ( ! hOut ) {
                MessageBox(NULL,"could not create output file","error",MB_OK|MB_ICONEXCLAMATION);
                return FALSE;
            }
            hOriginal = LoadLibrary("original.dll");
            if ( ! hOriginal ) {
                MessageBox(NULL,"could not load original library","error",MB_OK|MB_ICONEXCLAMATION);
                return FALSE;
            }
            Original_SCardTransmit = 
                (long (__stdcall *)(unsigned long,const struct _SCARD_IO_REQUEST *,const unsigned char *,unsigned long,struct _SCARD_IO_REQUEST *,unsigned char *,unsigned long *))
                    GetProcAddress(hOriginal,"SCardTransmit");
            if ( (!Original_SCardTransmit) ) {
                MessageBox(NULL,"could not find procedure address","error",MB_OK|MB_ICONEXCLAMATION);
                return FALSE;
            }
            break;
            
        case DLL_PROCESS_DETACH:
            FreeLibrary(hOriginal);
            CloseHandle(hOut);
            break;
            
        case DLL_THREAD_ATTACH:
            break;
            
        case DLL_THREAD_DETACH:
            break;
            
        default:
            MessageBox(NULL,"unknown DllMain reason code","error",MB_OK|MB_ICONEXCLAMATION);
            return FALSE;
            
    }
    
    return TRUE;

}

/* ******************************************************************************* */

}
